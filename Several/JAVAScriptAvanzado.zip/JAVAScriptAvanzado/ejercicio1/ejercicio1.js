function Persona(nombre,apellido){
    this.nombre = nombre; //incluir el this
    this.apellido = apellido;
    
}
function test1(){
    var p1 = new Persona("Hernan","Ludena"); 
    alert(p1.nombre+" "+p1.apellido);  //Object
}

function test2(){
    var p2 = Persona("Hernan","Ludena");  
    alert(p2.nombre); //undefined
}




