//alert("Un mensaje de prueba");
var mensaje ="Hola Mundo:\n Que facil es incluir \'comillas simples\' \n y \"comillas dobles\" ";
alert(mensaje);