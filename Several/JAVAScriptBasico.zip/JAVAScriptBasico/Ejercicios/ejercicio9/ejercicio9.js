function mOver(){    
document.imagen_nombre.src="imagenes/usa.jpg";    document.getElementById("imagen_id").src="imagenes/day.jpg";
}

function mOut(){    
document.imagen_nombre.src="imagenes/usa.jpg";   
}




/*

function Persona(nombre,apellido){
    this.nombre = nombre; //colcoar this siempre
    this.apellido = apellido;
    var x=5; //no es atributo
}

var p1=new Persona("xx","yy");
alert(p1.nombre);
p1.apellido='xxx';



*/