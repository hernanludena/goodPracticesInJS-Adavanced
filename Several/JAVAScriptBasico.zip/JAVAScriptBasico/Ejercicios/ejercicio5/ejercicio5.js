var nombres =["Ana","Marcelo"];

function agregar(){   
    var a = document.Cadena.dato.value.toUpperCase();
    nombres.push(a);      
    document.Cadena.resultado.value= nombres.join("-/-");    
}





